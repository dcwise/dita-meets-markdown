  
define(['require'], function (require) {
    require(['./jquery-cookie']);
    require(['./yeastar-common']);
    
});