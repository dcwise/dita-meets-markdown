  
define(['require'], function (require) {
    require(['./yeastar-common']);
    require(['./jquery-cookie']);
});