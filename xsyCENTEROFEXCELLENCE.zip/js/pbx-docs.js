  
define(['require'], function (require) {
    require(['./yeastar-common']);
    require(['./download-pdf']);
});